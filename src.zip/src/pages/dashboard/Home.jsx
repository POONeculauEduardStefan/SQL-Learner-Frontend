import React from 'react';

const Home = () => {
    return (
        <div className="mt-[300px]">
        </div>
    );
};

export default Home;