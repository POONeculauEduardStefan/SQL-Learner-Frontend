import React from 'react';

const Course11 = () => {
    return (
        <div className="flex flex-col gap-3">
            <p>In saptamana a 11-a:</p>
            <ul className="list-disc pl-5">
                <li>mica recapitulare: raspundem la intrebarile voastre</li>
                <li>test la laborator</li>
            </ul>
        </div>
    );
};

export default Course11;