import React from 'react';

const Course14 = () => {
    return (
        <div className="flex flex-col gap-3">
            <p>Obiective:</p>
            <p>Realizarea de exercitii cu: modelare a bazelor de date.</p>
            <h2 className="text-2xl text-blue-500">Exerciții</h2>
            <ol className="list-decimal pl-5">
                <li>Exercitii Entitate-Asociere</li>
            </ol>
            <h3 className="text-xl text-blue-500">Cursuri necesare acest laborator:</h3>
            <ul className="list-disc pl-5">
                <li>Curs 9</li>
            </ul>
        </div>
    );
};

export default Course14;