import React from 'react';

const Course8 = () => {
    return (
        <div className="flex flex-col gap-3">
            <p>In aceasta saptamana se recomanda studiul individual acasa (deoarece este saptamana in care se fac evaluari). Desi nu vom face evaluari la materia Baze de Date, ne dorim sa va consolidati cunostintele acumulate pana acum.</p>
        </div>
    );
};

export default Course8;