import React from 'react';

const Course5 = () => {
    return (
        <div className="flex flex-col gap-3">
            <p>In acest laborator:</p>
            <ul className="list-disc pl-5">
                <li>Recapitulare a cunoștințelor acumulate până în acest moment.</li>
                <li>Alte câteva exemple cu operatorul JOIN</li>
                <li>Primul test (conform cu fișa disciplinei) - cel care în secțiunea "Regulament" apare cu denumirea T1.</li>
            </ul>
        </div>
    );
};

export default Course5;