import React, {useState} from 'react';
import {Link, useNavigate} from 'react-router-dom';
import {toast} from "react-toastify";
import api from "../../services/api.js";
import {Mail} from 'lucide-react';
import {getErrorResponseMessage} from "../../utils/responses.jsx";
import {useTranslation} from "react-i18next";


const ForgotPassword = () => {
    const {t} = useTranslation();
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [loading, setLoading] = useState(false);

    const handleSignIn = async (e) => {
        e.preventDefault();
        setLoading(true);

        if (!email) {
            toast.error(t('common.please_fill_all_fields'));
            return;
        }
        try {
            const response = await api.post("/api/v1/auth/forgot-password", {
                email: email,
            })
            if (response.status === 200) {
                toast.success(t('auth.reset_link_sent'));
                navigate("/")
            }
        } catch (error) {
            const message = getErrorResponseMessage(error);
            toast.error(message);
        } finally {
            setLoading(false);
        }
    }

    return (
        <div
            className="bg-slate-900/50 backdrop-blur-xl rounded-2xl shadow-2xl border border-slate-800/50 p-6 sm:p-8 md:p-10">
            <div className="mb-8">
                <h2 className="text-3xl sm:text-4xl font-bold text-white mb-2">{t('common.welcome')}</h2>
                <p className="text-slate-400">{t('forgot_password.continue')}</p>
            </div>

            <form onSubmit={handleSignIn} className="space-y-5">
                <div>
                    <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-2">
                        {t('common.email')}
                    </label>
                    <div className="relative group">
                        <Mail
                            className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-blue-400 transition-colors"/>
                        <input
                            id="email"
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full pl-12 pr-4 py-3.5 bg-slate-800/50 border border-slate-700/50 rounded-xl text-white placeholder-slate-500 focus:bg-slate-800 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
                            placeholder="your@email.com"
                            required
                        />
                    </div>
                </div>

                <button
                    type="submit"
                    disabled={loading}
                    className="w-full mt-8 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-600 text-white font-semibold py-3.5 rounded-xl transition-all transform hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 shadow-lg shadow-blue-500/25 cursor-pointer"
                >
                    {loading ? t('auth.send_reset_link_loading') : t('auth.send_reset_link')}
                </button>
            </form>

            <div className="mt-8 text-center">
                <p className="text-slate-400 text-sm">
                    {t('auth.no_account')}{' '}
                    <Link to="/auth/sign-up"
                          className="text-blue-400 hover:text-blue-300 font-semibold transition-colors">
                        {t('auth.sign_up')}
                    </Link>
                </p>
            </div>
        </div>
    );
};

export default ForgotPassword;